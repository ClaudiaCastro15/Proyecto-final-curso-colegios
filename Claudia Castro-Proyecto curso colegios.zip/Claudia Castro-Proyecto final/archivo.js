<button type="button" class="btn btn-dark" onclick="cambiarModo()">Oscuro / Claro</button>
function cambiarModo() {
    var cuerpoweb = document.body;
    cuerpoweb.classList.toggle("Oscuro")
}

<script type="text-javascript">
    function cambiarModo() {
    var cuerpoweb = document.body;
    cuerpoweb.classList.toggle("Oscuro")
        
    }
</script>